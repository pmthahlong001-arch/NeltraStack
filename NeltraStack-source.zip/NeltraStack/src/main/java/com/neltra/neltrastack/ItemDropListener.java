package com.neltra.neltrastack;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ItemSpawnEvent;

public class ItemDropListener implements Listener {

    private final NeltraStack plugin;

    public ItemDropListener(NeltraStack plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onItemSpawn(ItemSpawnEvent event) {
        Item item = event.getEntity();

        if (plugin.getStackManager().isBlacklisted(item.getItemStack().getType())) return;

        // Folia: dùng RegionScheduler để schedule task tại location của item
        // Delay 1 tick để item spawn xong rồi mới gộp
        plugin.getServer().getRegionScheduler().runDelayed(
            plugin,
            item.getLocation(),
            task -> {
                if (!item.isValid()) return;
                plugin.getStackManager().tryMerge(item);
            },
            plugin.getConfig().getLong("merge-delay-ticks", 20L)
        );
    }
}
