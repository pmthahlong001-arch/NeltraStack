package com.neltra.neltrastack;

import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.inventory.ItemStack;

public class ItemPickupListener implements Listener {

    private final NeltraStack plugin;

    public ItemPickupListener(NeltraStack plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        Item item = event.getItem();
        int realAmount = plugin.getStackManager().getRealAmount(item);
        int vanillaAmount = item.getItemStack().getAmount();

        // Nếu không có stacking thì bỏ qua
        if (realAmount <= vanillaAmount) return;

        // Cancel event mặc định, tự xử lý pickup
        event.setCancelled(true);

        ItemStack baseStack = item.getItemStack().clone();
        int maxPerSlot = baseStack.getMaxStackSize();
        int remaining = realAmount;

        // Thêm từng stack vào inventory player
        while (remaining > 0) {
            int toGive = Math.min(remaining, maxPerSlot);
            baseStack.setAmount(toGive);

            // Thêm vào inventory
            java.util.HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(baseStack.clone());

            if (!leftover.isEmpty()) {
                // Inventory đầy, drop phần còn lại ra đất
                remaining = 0;
                for (ItemStack leftoverStack : leftover.values()) {
                    remaining += leftoverStack.getAmount();
                }
                if (remaining > 0) {
                    // Drop lại item với số lượng còn lại
                    Item dropped = player.getWorld().dropItem(item.getLocation(), baseStack.clone());
                    plugin.getStackManager().setRealAmount(dropped, remaining);
                    // Pickup cooldown để tránh loop
                    dropped.setPickupDelay(40);
                }
                break;
            }
            remaining -= toGive;
        }

        // Xóa item entity gốc
        item.remove();

        // Pickup sound & animation
        player.getWorld().playSound(
            player.getLocation(),
            org.bukkit.Sound.ENTITY_ITEM_PICKUP,
            0.2f,
            (float)(1.0 + Math.random() * 0.2)
        );
    }
}
